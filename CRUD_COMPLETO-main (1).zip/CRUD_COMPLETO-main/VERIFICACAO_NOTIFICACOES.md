# Verificação do módulo — 29/10/2026

Resultado: módulo de notificações aprovado nos testes abaixo. O escopo é o novo módulo e sua integração nas páginas existentes; não é uma aprovação de todos os módulos originais.

- JavaScript: três testes automatizados das regras de destino, revisão/leitura e combinação de filtros. Falha inicial observada com as regras ausentes; os mesmos testes passaram após a implementação.
- Sintaxe: os três arquivos JavaScript novos e o arquivo PHP novo foram verificados sem erros.
- Banco real: importação completa em MariaDB 10.11 e reaplicação da migração sem perda de alertas.
- PHP 8.3 + MariaDB: consulta, cadastro, alteração, exclusão, texto UTF-8 com emoji, token de sessão, rejeição de JSON inválido, campos inválidos, linha inexistente, método incorreto e conflito de revisão.
- Chromium: cadastro por formulário, texto HTML tratado como texto, busca, filtros, destino por aba, leitura mantida após recarregar, nova revisão não lida, ativação/desativação, exclusão confirmada, contador e erro de rede.
- Integração: avisos globais presentes na página inicial, Usuários, Linhas, Itinerários, Pontos, Horários e na página de alteração de Linhas. Alerta exclusivo de Linhas ausente em Pontos.
- Interface: revisão visual em 1280, 768 e 375 pixels; nenhum excesso de largura horizontal nesses tamanhos. Cores de texto e campos conferidas com os tokens do CSS. Não é uma auditoria completa de acessibilidade nem um teste em todos os navegadores.
- A central nova terminou sem erros de JavaScript nos testes. As telas antigas apresentaram erros já existentes, como declaração duplicada de `id` em Linhas e chamadas a endereços fixos antigos. Esses módulos não foram refeitos.

Os testes usaram banco descartável, conteúdo marcado como exemplo e uma cópia da conexão apontada para TCP local, necessária ao ambiente Linux de teste. O arquivo `php/conexao.php` entregue conserva a configuração original para XAMPP; nenhum dado de teste foi incluído no SQL da entrega.

O ciclo de falha inicial e aprovação posterior foi registrado para as regras JavaScript e para a correção de UTF-8. Os testes completos de API e navegador foram executados depois da implementação; não são apresentados como um ciclo TDD integral.

Para repetir a conferência no seu computador, siga a sequência manual em `LEIA-ME_NOTIFICACOES.md`. Testes locais não confirmam as credenciais e a instalação do XAMPP de outro computador.
