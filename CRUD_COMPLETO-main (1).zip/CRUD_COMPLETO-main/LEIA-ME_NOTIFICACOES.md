# BusMap — central de notificações

## Instalar no XAMPP

1. Extraia a pasta `CRUD_COMPLETO-main`. Para manter os caminhos dos módulos antigos, renomeie a pasta extraída para **busmap** e coloque-a em `C:\xampp\htdocs\busmap`.
2. Abra o XAMPP e inicie **Apache** e **MySQL**.
3. Confira as credenciais em `php/conexao.php` (padrão do pacote: localhost:3306, root, senha vazia, banco busmap).
4. Se o banco **já existe**, importe apenas `sql/alertas_migracao.sql` pelo phpMyAdmin ou execute-o no MySQL Workbench. Ele cria a tabela `alerta` sem apagar os registros existentes.
5. Se é uma instalação **nova**, importe `sql/busmap.sql`. A tabela de alertas já está incluída ao final; não precisa importar os dois arquivos.
6. Abra **http://localhost/busmap/** e clique em **Notificações**. Acesso direto: **http://localhost/busmap/home/Notificacoes/notificacoes.html**.

Não abra o HTML por duplo clique (`file://`) ou pelo Live Server: o servidor precisa executar o PHP. PHP 7.4+ com mysqli/mysqlnd (incluídos no XAMPP) e MySQL/MariaDB com InnoDB.

A migração foi feita para o ZIP fornecido, que não continha tabela de alertas. Se você criou outra tabela `alerta` manualmente com estrutura diferente, guarde uma cópia e adapte a estrutura antes de usar este módulo: `CREATE TABLE IF NOT EXISTS` não altera uma tabela já existente.

## Como usar

- **Novo alerta:** preencha título e descrição; selecione a aba, prioridade e, se necessário, uma linha; clique em **Cadastrar alerta**.
- **Todas as abas:** mostra o aviso na página inicial e nas cinco abas existentes. Um destino específico mostra o aviso apenas nas páginas daquela aba. A central sempre permite consultar todos os destinos.
- **Linha vinculada:** identifica a linha afetada; não modifica a aba de destino.
- **Prioridade:** Informação, Atenção e Urgente. A lista coloca os urgentes primeiro e, na mesma prioridade, os registros mais recentes por ID.
- **Ativo:** gera avisos e participa do contador. Desmarque a opção e salve para manter o registro apenas no histórico de inativos.
- **Editar:** carregue um registro no formulário, altere os campos e clique em **Salvar alterações**. Uma nova revisão volta a aparecer como não lida.
- **Excluir:** confirme a remoção do registro. Para manter histórico, prefira desativar.
- **Marcar como lido:** vale para este navegador e esta pasta do projeto. Não modifica o banco nem a leitura em outros computadores. Se o armazenamento do navegador estiver bloqueado, a leitura vale somente na página aberta e uma mensagem informa isso.
- **Marcar todos os ativos como lidos:** inclui todos os destinos, mesmo quando a lista estiver filtrada.
- **Filtros:** busca por título/descrição/código da linha, aba, ativo/inativo e lido/não lido. O filtro de aba inclui também os avisos destinados a todas as abas.
- **Contador do menu:** total de alertas ativos não lidos, considerando todos os destinos.
- **Avisos das abas:** mostram até três alertas não lidos e um link para consultar os demais. A consulta é refeita a cada 30 segundos com a página visível e quando você retorna à página.

São notificações dentro do site. Não há envio por e-mail, push do sistema operacional ou aviso com o navegador fechado. A central inicia vazia; os registros são criados pelo formulário.

## Arquivos do módulo

| Tecnologia | Arquivos |
|---|---|
| HTML | `home/Notificacoes/notificacoes.html` |
| CSS | `css/notificacoes.css` |
| JavaScript da central | `home/Notificacoes/notificacoes.js` |
| JavaScript compartilhado | `js/notificacoes/compartilhado.js`, `js/notificacoes/core.js` |
| PHP | `php/Notificacoes/api.php` |
| SQL para banco existente | `sql/alertas_migracao.sql` |

As sete páginas originais receberam a identificação da aba, o link Notificações no menu e os carregamentos do CSS/JS compartilhados. O JavaScript atualiza o contador e insere os avisos. `sql/busmap.sql` recebeu a nova tabela ao final.

## API PHP

URL: `php/Notificacoes/api.php`. Respostas JSON com `status`, `mensagem`, `data` e `csrf`.

- **GET:** lista os alertas; `?recurso=linhas` retorna as linhas para o seletor.
- **POST:** cria um alerta com `titulo`, `descricao`, `aba`, `prioridade`, `ativo` (0 ou 1) e `id_linha` (opcional/null).
- **PUT:** altera; exige também `id` e `revisao` atuais.
- **DELETE:** exclui; exige `id` e `revisao` atuais.

Escritas exigem JSON e o cabeçalho `X-CSRF-Token` recebido no GET, com o mesmo cookie de sessão. O JavaScript já faz isso. Consultas preparadas, validação no servidor, textos via `textContent` e controle de revisão protegem o novo módulo contra injeção SQL, interpretação de HTML e sobrescrita de alterações concorrentes. Não foi acrescentado controle de acesso: o projeto original não tinha login/sessão implementados (`php/valida_sessao.php` está vazio), e a central é acessível a quem abrir o site.

## Limites do projeto original

Este pacote adiciona o módulo de alertas. Não conclui os módulos anteriores: vários arquivos PHP de Usuários, Pontos, Itinerários e Horários contêm apenas um comentário. Os scripts antigos de Linhas usam URLs fixas `http://localhost/busmap/...`, por isso a pasta recomendada continua sendo `busmap`. O novo módulo usa caminhos relativos. O Bootstrap das telas antigas continua vindo do CDN original; a tela nova possui CSS próprio e não depende desse CDN.

## Conferência manual rápida

1. Cadastre um alerta de Atenção para **Linhas**, vinculado à linha **030**.
2. Abra Linhas: confira o aviso e o contador. Abra Pontos: o aviso específico de Linhas não deve aparecer.
3. Marque o aviso como lido e recarregue: ele deve continuar lido no mesmo navegador.
4. Edite a descrição na central: a revisão nova deve reaparecer como não lida.
5. Desative o alerta: ele deve sumir dos avisos e aparecer no filtro **Inativos**.
6. Cadastre outro alerta para **Todas as abas** e verifique a página inicial e as cinco abas.
7. Teste a exclusão com confirmação e os filtros da central.
